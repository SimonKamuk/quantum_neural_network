#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 13:24:14 2022

@author: simon
"""

from qiskit import QuantumCircuit, BasicAer
from qiskit.algorithms import EstimationProblem,FasterAmplitudeEstimation
from qiskit.extensions import UnitaryGate
import numpy as np
import sys

from qiskit.quantum_info.operators import Operator
from qiskit.utils import QuantumInstance



class BernoulliA(QuantumCircuit):
    """A circuit representing the Bernoulli A operator."""

    def __init__(self, theta1, theta2):
        super().__init__(2)  # circuit on 2 qubit

        self.h(0)
        self.cry(theta1, 0, 1)
        self.x(0)
        self.cry(theta2, 0, 1)
        self.h(0)
        
        
class BernoulliA_4qb(QuantumCircuit):
    """A circuit representing the Bernoulli A operator."""

    def __init__(self, v,c):
        super().__init__(5)  # circuit on 5 qubit
        
        v = v/np.linalg.norm(v,ord=2)
        c = c/np.linalg.norm(c,ord=2)
        
        self.h(0)
        self.state4(v)
        self.x(0)
        self.state4(c)
        self.h(0)
        
    def state2(self,c):
        c = c.reshape((2,2))
        c = c.transpose()
        u,s,vh = np.linalg.svd(c)
        vh = vh.transpose()
        theta = np.arccos(np.clip(s[0],-1,1))
        self.cry(2*theta,0,1)
        self.ccx(0,1,2)
        u_gate = UnitaryGate(u).control(1)
        self.append(u_gate,[0,1])
        vh_gate = UnitaryGate(vh).control(1)
        self.append(vh_gate,[0,2])
        
    def state4(self,v):
        v = v.reshape((4,4))
        v = v.transpose()
        u,s,vh = np.linalg.svd(v)
        vh = vh.transpose()
        self.state2(s)
        self.ccx(0,1,3)
        self.ccx(0,2,4)
        u_gate = UnitaryGate(u).control(1)
        self.append(u_gate,[0,1,2])
        vh_gate = UnitaryGate(vh).control(1)
        self.append(vh_gate,[0,3,4])


class BernoulliA_4qb_computed(QuantumCircuit):
    """A circuit representing the Bernoulli A operator."""

    def __init__(self, v,c):
        super().__init__(5)  # circuit on 5 qubit

        A = Operator(BernoulliA_4qb(v,c))
        
        self.append(A,list(range(5)))
        

if __name__ == 'main':
    if len(sys.argv) == 1:
        jobidx=0
        l=5
        delta_c=0.1
        outfile = None
        num_reps = 1
        
    else:
        jobidx = int(sys.argv[3])   
        delta_c = float(sys.argv[1])
        l = int(sys.argv[2])
        if len(sys.argv) > 4:
            ip_true = float(sys.argv[4])
            outfile = f'outputs/outfile_del_{delta_c}_l_{l}_iptrue_{ip_true}_job_{jobidx}.txt'
            num_reps = 5
        else:
            outfile = f'outputs/outfile_del_{delta_c}_l_{l}_job_{jobidx}.txt'
            ip_true = None        
            num_reps = 10
    
    
    first_seed = 2022
    np.random.seed(first_seed)
    np.random.seed(int((hash(tuple(sys.argv))/2**sys.hash_info[0]+0.5)*np.random.randint(low=2**26,high=2**30)))
    print(sys.argv, int((hash(tuple(sys.argv))/2**sys.hash_info[0]+0.5)*np.random.randint(low=2**26,high=2**30)))
    
    
    v = np.ones(16)
    
    if ip_true == None:
        c = np.array([ 1.38444794, -1.15961516,  0.89357079, -1.0291141 ,  0.26078641,
                0.91795571, -0.49167731, -0.74554951,  0.1772755 , -0.09699524,
                0.20297779,  0.83008654, -0.49868429, -1.13100931, -1.06091661,
               -1.27562477])
        #ip_true = np.inner(v,c)/(np.linalg.norm(v,ord=2)*np.linalg.norm(c,ord=2)) # = -0.2047019986566411
        
    else:
        c = np.ones(16)
        c[0] = -(-15 + 16*np.sqrt(-15*ip_true**4 + 15*ip_true**2))/(16*ip_true**2 - 1)
        if ip_true < 0:
            v*=-1
        
        
    
    
    
    
    backend = BasicAer.get_backend("qasm_simulator")
    # backend = BasicAer.get_backend("statevector_simulator")
    quantum_instance = QuantumInstance(backend)
    
    A = BernoulliA_4qb_computed(v,c)
    
    problem = EstimationProblem(
        state_preparation=A,  # A operator
        objective_qubits=[0],  # the "good" state Psi1 is identified as measuring |1> in qubit 0
        is_good_state=None
    )
    
    results = []
    
    
    
    for i in range(num_reps):
        
        quantum_instance.set_config(seed_simulator=np.random.randint(2**30))
        ae = FasterAmplitudeEstimation(
                delta=delta_c,
                maxiter=l,
                quantum_instance = quantum_instance,
                rescale=True
        )
        
        
        ae_result = ae.estimate(problem)
        ip_est = 1-ae_result.estimation*2
        results.append(str(ip_est))
        
        
    if outfile is not None:
        with open(outfile, 'w+') as file:
            file.write('\n'.join(results))
    else:
        ip_true = np.inner(v,c)/(np.linalg.norm(v,ord=2)*np.linalg.norm(c,ord=2))
        print(ip_true)
        print(ip_true-ip_est)
        
        



