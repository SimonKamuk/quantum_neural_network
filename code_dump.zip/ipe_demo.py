#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 13:24:14 2022

@author: simon
"""

from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, BasicAer
from qiskit.algorithms import AmplitudeEstimation,EstimationProblem,FasterAmplitudeEstimation,IterativeAmplitudeEstimation
from qiskit.circuit import Parameter
from numpy import pi, cos, sin
import matplotlib
#matplotlib.use('Qt5Agg')
import matplotlib.pyplot as plt
import numpy as np

from qiskit.quantum_info.operators import Operator
from qiskit.utils import QuantumInstance





backend = BasicAer.get_backend("statevector_simulator")
quantum_instance = QuantumInstance(backend)


class BernoulliA(QuantumCircuit):
    """A circuit representing the Bernoulli A operator."""

    def __init__(self, theta1, theta2):
        super().__init__(2)  # circuit on 2 qubit

        self.h(0)
        self.cry(theta1, 0, 1)
        self.x(0)
        self.cry(theta2, 0, 1)
        self.h(0)
        

class BernoulliA_transpose(QuantumCircuit):
    """A circuit representing the transpose of the Bernoulli A operator."""

    def __init__(self, theta1, theta2):
        super().__init__(2)  # circuit on 2 qubit

        self.h(0)
        self.cry(-theta2, 0, 1)
        self.x(0)
        self.cry(-theta1, 0, 1)
        self.h(0)

class S_0_class(QuantumCircuit):
    def __init__(self):
        super().__init__(2)
        self.x([0,1])
        self.cz([1],0)
        self.x([0,1])
        
    
class neg_S_Psi1_class(QuantumCircuit):
    def __init__(self):
        super().__init__(2)
        self.x(0)
        self.z(0)
        self.x(0)

class BernoulliQ(QuantumCircuit):
    """A circuit representing the Bernoulli Q operator."""

    def __init__(self,theta1, theta2):
        super().__init__(2)  # circuit on 2 qubit
        
        A = BernoulliA(theta1, theta2)
        A_transpose = BernoulliA_transpose(theta1, theta2)
        S_0 = S_0_class()
        neg_S_Psi1 = neg_S_Psi1_class()
        
        
        self.compose(neg_S_Psi1, inplace=True )
        self.compose(A_transpose, inplace=True)
        self.compose(S_0, inplace=True)
        self.compose(A, inplace=True)
        
        

theta1_val, theta2_val = 2*np.pi/6, 0

theta1 = Parameter('theta1')
theta2 = Parameter('theta2')

param_dict = {theta1: theta1_val, theta2: theta2_val}

param_dict={}

A = BernoulliA(theta1,theta2).assign_parameters(param_dict)
# A.draw(output='mpl')
# plt.tight_layout()
# plt.savefig('A_circuit.pdf')

Q = BernoulliQ(theta1,theta2).assign_parameters(param_dict)



# Q.draw(output='mpl')
# plt.tight_layout()
# plt.savefig('Q_circuit.pdf')

# Q.decompose().draw(output='mpl')


ae = AmplitudeEstimation(
        num_eval_qubits=6,  # the number of evaluation qubits specifies circuit width and accuracy
        quantum_instance = quantum_instance
)

# ae = FasterAmplitudeEstimation(
#         delta=0.01,
#         maxiter=3,
#         quantum_instance = quantum_instance,
#         rescale=False
# )


# ae = IterativeAmplitudeEstimation(
#     epsilon_target=0.01,
#     alpha=0.05,
#     quantum_instance=quantum_instance
# )





problem = EstimationProblem(
    state_preparation=A,  # A operator
    grover_operator=Q,  # Q operator
    objective_qubits=[0],  # the "good" state Psi1 is identified as measuring |1> in qubit 0
    is_good_state=None
)


ae_result = ae.estimate(problem)
#fae_result = fae.estimate(problem)
print(1-ae_result.estimation*2)
print(cos(theta1_val/2)*cos(theta2_val/2)+sin(theta1_val/2)*sin(theta2_val/2))

gridpoints = list(ae_result.samples.keys())
probabilities = list(ae_result.samples.values())

plt.figure()
p = (1-(cos(theta1_val/2)*cos(theta2_val/2)+sin(theta1_val/2)*sin(theta2_val/2)))/2
plt.bar(gridpoints, probabilities, width=0.5 / len(probabilities))
plt.axvline(p, color="r", ls="--")
plt.xticks(size=15)
plt.yticks([0, 0.25, 0.5, 0.75, 1], size=15)
plt.title("Estimated Values", size=15)
plt.ylabel("Probability", size=15)
plt.xlabel(r"Amplitude $a$", size=15)
plt.ylim((0, 1))
plt.grid()
plt.show()


# cos2cos2=cos(theta1_val/2)*cos(theta1_val/2) * cos(theta2_val/2)*cos(theta2_val/2)
# op=Operator([[-1,0,0,0],[0,cos2cos2,0,0],[0,0,cos2cos2,0],[0,0,0,cos2cos2]])
# np.array(Operator(Q)) @ np.array(op) - np.array(Operator(Q))@np.array(Operator(Q))





#%%

# for theta1_val in np.linspace(0,2*pi,5):
#     for theta2_val in np.linspace(0,2*pi,4):

#         param_dict = {theta1: theta1_val, theta2: theta2_val}
        
#         A = BernoulliA(theta1,theta2).assign_parameters(param_dict)
#         Q = BernoulliQ(theta1,theta2).assign_parameters(param_dict)
#         problem = EstimationProblem(
#             state_preparation=A,  # A operator
#             grover_operator=Q,  # Q operator
#             objective_qubits=[0],  # the "good" state Psi1 is identified as measuring |1> in qubit 0
#             is_good_state=None
#         )
        
        
#         ae_result = ae.estimate(problem)
#         print('')
#         print(1-ae_result.estimation*2)
#         print(cos(theta1_val/2)*cos(theta2_val/2)+sin(theta1_val/2)*sin(theta2_val/2))

