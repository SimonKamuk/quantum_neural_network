#!/bin/bash
##Kør på gpu
##BSUB -q gpuk80
##Antal gpuer vi vil bruge. Kommenter ud hvis cpu.
##BSUB -gpu "num=1:mode=exclusive_process"

##Kør på cpu
#BSUB -q hpc

##Navn på job
#BSUB -J qnn_distribution_[1-200]
##Output fil
#BSUB -o log/qnn_distribution_-%J.out
##Antal kerner
#BSUB -n 1
##Om kernerne må være på forskellige computere
#BSUB -R "span[hosts=1]"
##Ram pr kerne
#BSUB -R "rusage[mem=2GB]"
##Hvor lang tid må den køre hh:mm
#BSUB -W 48:00
##Email når jobbet starter
##BSUB -B
##og stopper
##BSUB -N

module purge
module load numpy/1.22.3-python-3.9.11-openblas-0.3.19

deltac=0.1
l=3

for ip_true in 0.7
do
    python3 distribution.py $deltac $l $LSB_JOBINDEX $ip_true
done
