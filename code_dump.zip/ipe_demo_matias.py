#!/usr/bin/env python3

from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, BasicAer
from qiskit.circuit import Parameter
from qiskit.algorithms import AmplitudeEstimation,EstimationProblem,FasterAmplitudeEstimation
from numpy import pi, cos, sin
import matplotlib
#matplotlib.use('Qt5Agg')
import matplotlib.pyplot as plt
import numpy as np
from qiskit.compiler import transpile
from qiskit.algorithms.exceptions import AlgorithmError

from qiskit.quantum_info.operators import Operator
from qiskit.utils import QuantumInstance
from qiskit import IBMQ


class ModifiedFasterAmplitudeEstimation(FasterAmplitudeEstimation):
    def _cos_estimate(self, estimation_problem, k, shots):
        if self._quantum_instance is None:
            raise AlgorithmError("Quantum instance must be set.")

        if self._quantum_instance.is_statevector:
            circuit = self.construct_circuit(estimation_problem, k, measurement=False)
            statevector = self._quantum_instance.execute(circuit).get_statevector()

            # sum over all amplitudes where the objective qubits are 1
            prob = 0
            for i, amplitude in enumerate(statevector):
                # get bitstring of objective qubits
                full_state = bin(i)[2:].zfill(circuit.num_qubits)[::-1]
                state = "".join([full_state[i] for i in estimation_problem.objective_qubits])

                # check if it is a good state
                if estimation_problem.is_good_state(state[::-1]):
                    prob = prob + np.abs(amplitude) ** 2

            cos_estimate = 1 - 2 * prob
        else:
            circuit = self.construct_circuit(estimation_problem, k, measurement=True)
            #THE FOLLOWING IS MODIFIED TO SUBMIT AS JOB:
            circuit = transpile(circuit,self.quantum_instance.backend)
            circuit.draw(output='mpl').show()
            plt.show()
            plt.tight_layout()
            plt.savefig('ionq_circuit.pdf')

            plt.show()
            plt.tight_layout()
            job = self._quantum_instance.backend.run(circuit, shots=shots)
            #job_id = job.id()
            #print("Job id", job_id)
            result = job.result()
            print(result)
            
            #self._quantum_instance.run_config.shots = shots
            #counts = self._quantum_instance.execute(circuit).get_counts()
            counts = result.get_counts(circuit)
            self._num_oracle_calls += (2 * k + 1) * shots

            good_counts = 0
            for state, count in counts.items():
                if estimation_problem.is_good_state(state):
                    good_counts += count

            cos_estimate = 1 - 2 * good_counts / shots

        return cos_estimate



#Initialize backend - The source of Quantum. In this case we use a quantum statevector simulator
backend = BasicAer.get_backend("qasm_simulator")
quantum_instance = QuantumInstance(backend)

class BernoulliA(QuantumCircuit):
    """A circuit representing the Bernoulli A operator."""

    def __init__(self, theta1, theta2):
        super().__init__(2)  # circuit on 2 qubit

        self.h(0)
        self.cry(theta1, 0, 1)
        self.x(0)
        self.cry(theta2, 0, 1)
        self.h(0)

class BernoulliA_trans(QuantumCircuit):
    """A circuit representing the transposed Bernoulli A operator."""

    def __init__(self, theta1, theta2):
        super().__init__(2)  # circuit on 2 qubit

        self.h(0)
        self.cry(-theta2, 0, 1)
        self.x(0)
        self.cry(-theta1, 0, 1)
        self.h(0)

class BernoulliQ(QuantumCircuit):
    """A circuit representing the Bernoulli Q operator."""

    def __init__(self,theta1, theta2):
        super().__init__(2)  # circuit on 2 qubit
        
        A = BernoulliA(theta1, theta2)
        A_trans = BernoulliA_trans(theta1,theta2)
        
        self.x(0)
        self.z(0)
        self.x(0)
        self.compose(A_trans,inplace=True)
        self.x([0,1])
        self.cz([1],0)
        self.x([0,1])
        self.compose(A,inplace=True)
    
        
#Angles of the rotations used in the initilization of |v> and |c>. 
theta1, theta2 = 2*pi/6,0
A = BernoulliA(theta1,theta2)
Q = BernoulliQ(theta1,theta2)

#Uncomment the following to draw circuits:
"""
Q.draw(output='mpl').show()
plt.show()
plt.tight_layout()
plt.savefig('Q_circuit.pdf')

A.draw(output='mpl').show()
plt.show()
plt.tight_layout()
plt.savefig('A_circuit.pdf')
"""


#%%
#Algorithm for original amplitude estimation. 
M=6
ae = AmplitudeEstimation(
        num_eval_qubits=M,  # the number of evaluation qubits specifies circuit width and accuracy
        quantum_instance = quantum_instance
)

#Faster amplitude estimation algorithm
fae = FasterAmplitudeEstimation(
      delta=0.01,  # target accuracy
      maxiter=1,  # determines the maximal power of the Grover operator
      quantum_instance=quantum_instance,
      rescale=True
)

#Define estimation problem
problem = EstimationProblem(
    state_preparation=A,  # A operator
    grover_operator=Q,  # Q operator
    objective_qubits=[0],  # the "good" state Psi1 is identified as measuring |1> in qubit 0
    is_good_state=None
)

#Calculate estimate for amplitude (uncomment following to use original amplitude estimation (slow))
#ae_result = ae.estimate(problem)
ae_result = fae.estimate(problem)
ip = np.cos(theta1/2)*np.cos(theta2/2)+np.sin(theta1/2)*np.sin(theta2/2)
ie = 1-2*ae_result.estimation
#Compare expected result with obtained result
print('Inner product estimate: {es:.5f}'.format(es = ie))
print('Expected result       : {es:.5f}'.format(es = ip))
print('Deviation             : {es:.5f}'.format(es = (ip-ie)/(ip)))


#Uncomment the following if using original ampltitude estimation to see state probabilities

def error(a,k,M):
    return 2*np.pi*k*np.sqrt(a*(1-a))/M+k**2/M**2*np.pi

gridpoints = list(ae_result.samples.keys())
probabilities = list(ae_result.samples.values())

plt.figure()
p = 1/2-cos(theta1/2)*cos(theta2/2)/2-sin(theta1/2)*sin(theta2/2)/2
plt.bar(gridpoints, probabilities, width=0.5 / len(probabilities))
plt.axvline(p, color="r", ls="--")
plt.axvline(p+error(p,1,2**M), color="r", ls="--")
plt.axvline(p-error(p,1,2**M), color="r", ls="--")
plt.axvline(p+error(p,2,2**M), color="b", ls="--")
plt.axvline(p-error(p,2,2**M), color="b", ls="--")
plt.axvline(p+error(p,3,2**M), color="g", ls="--")
plt.axvline(p-error(p,3,2**M), color="g", ls="--")
plt.axvline(p+error(p,4,2**M), color="g", ls="--")
plt.axvline(p-error(p,4,2**M), color="g", ls="--")
plt.axvline(p+error(p,5,2**M), color="g", ls="--")
plt.axvline(p-error(p,5,2**M), color="g", ls="--")



plt.xticks(size=15)
plt.yticks([0, 0.25, 0.5, 0.75, 1], size=15)
plt.title("Estimated Values", size=15)
plt.ylabel("Probability", size=15)
plt.xlabel(r"Amplitude $a$", size=15)
plt.ylim((0, 1))
plt.grid()
plt.show()


