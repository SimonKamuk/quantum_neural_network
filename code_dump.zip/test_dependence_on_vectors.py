#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 12 15:14:14 2022

@author: simon
"""


import numpy as np
from skimage.transform import resize
from skimage.util import img_as_ubyte
import matplotlib.pyplot as plt
import cProfile, pstats

import pickle
# from keras.datasets import mnist
# import pandas as pd
# from numba.experimental import jitclass
# from numba import jit
# import sys

from qiskit import QuantumCircuit, BasicAer
from qiskit.algorithms import EstimationProblem,FasterAmplitudeEstimation
from qiskit.extensions import UnitaryGate
from qiskit.quantum_info.operators import Operator
from qiskit.utils import QuantumInstance

np.seterr(all='raise')
np.random.seed(2022)


delta_c = 0.05
l = 5 #l=1: 590ms, l=2: 790ms, l=3: 1770ms

class BernoulliA(QuantumCircuit):
    """A circuit representing the Bernoulli A operator."""

    def __init__(self, theta1, theta2):
        super().__init__(2)  # circuit on 2 qubit

        self.h(0)
        self.cry(theta1, 0, 1)
        self.x(0)
        self.cry(theta2, 0, 1)
        self.h(0)
        
        
class BernoulliA_4qb(QuantumCircuit):
    """A circuit representing the Bernoulli A operator."""

    def __init__(self, v,c):
        super().__init__(5)  # circuit on 5 qubit
        
        v = v/np.linalg.norm(v,ord=2)
        c = c/np.linalg.norm(c,ord=2)
        
        self.h(0)
        self.state4(v)
        self.x(0)
        self.state4(c)
        self.h(0)
        
    def state2(self,c):
        c = c.reshape((2,2))
        c = c.transpose()
        u,s,vh = np.linalg.svd(c)
        vh = vh.transpose()
        theta = np.arccos(np.clip(s[0],-1,1))
        self.cry(2*theta,0,1)
        self.ccx(0,1,2)
        u_gate = UnitaryGate(u).control(1)
        self.append(u_gate,[0,1])
        vh_gate = UnitaryGate(vh).control(1)
        self.append(vh_gate,[0,2])
        
    def state4(self,v):
        v = v.reshape((4,4))
        v = v.transpose()
        u,s,vh = np.linalg.svd(v)
        vh = vh.transpose()
        self.state2(s)
        self.ccx(0,1,3)
        self.ccx(0,2,4)
        u_gate = UnitaryGate(u).control(1)
        self.append(u_gate,[0,1,2])
        vh_gate = UnitaryGate(vh).control(1)
        self.append(vh_gate,[0,3,4])


class BernoulliA_4qb_computed(QuantumCircuit):
    """A circuit representing the Bernoulli A operator."""

    def __init__(self, v,c):
        super().__init__(5)  # circuit on 5 qubit

        A = Operator(BernoulliA_4qb(v,c))
        
        self.append(A,list(range(5)))
        
backend = BasicAer.get_backend("qasm_simulator")
quantum_instance = QuantumInstance(backend)
ae = FasterAmplitudeEstimation(
        delta=delta_c,
        maxiter=l,
        quantum_instance = quantum_instance,
        rescale=True
)






reps = 100
est = np.ones(reps)
true = np.ones(reps)
for i in range(reps):
    a = np.random.randint(-10,10,16)
    b = np.random.randint(-10,10,16)
    norms = np.linalg.norm(a,ord=2)*np.linalg.norm(b,ord=2)
    A = BernoulliA_4qb_computed(a,b)
    problem = EstimationProblem(
        state_preparation=A,  # A operator
        objective_qubits=[0],  # the "good" state Psi1 is identified as measuring |1> in qubit 0
        is_good_state=None
    )
    ae_result = ae.estimate(problem)
    ip_est = 1-ae_result.estimation*2
    
    est[i],true[i] = ip_est, np.inner(a,b)/norms


with open('standard_deviation_pickle','rb') as file:
    normalized_std_fun = pickle.load(file)
    
ip_range = np.arange(-1,1,0.01)

plt.plot(true,np.abs(est-true),'.')
plt.plot(ip_range,normalized_std_fun(ip_range))
plt.xlabel('Normalized inner product')
plt.ylabel('Error')
plt.title(r'$l=5$, $\delta_c=0.05$')
plt.legend(['Error from random vectors','Smoothed curve from simple vectors'])
plt.savefig('figures/inner_prod_error_random_vecs.pdf')
