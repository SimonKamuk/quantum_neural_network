#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 22 11:27:49 2022

@author: simon
"""

import numpy as np
import matplotlib.pyplot as plt
import os
import shutil
from scipy.stats import norm
from scipy.interpolate import interp1d
from scipy.signal import savgol_filter
import pickle

# np.seterr(all='raise')

local_folder = 'output_std_tests_ip'
# local_folder = 'normal_distribution'
# local_folder = 'gbar_outputs'
reload_files = False
if reload_files:
    # Pull
    # os.system(f'rsync -avh -e ssh  s173977@transfer.gbar.dtu.dk:~/qnn_project/outputs/ {local_folder}/')

    # Push
    #scp local_file s173977@transfer.gbar.dtu.dk:~/qnn_project/
    
    if os.path.exists(local_folder+'_combined'):
        shutil.rmtree(local_folder+'_combined')
    os.mkdir(local_folder+'_combined')
    
    for file in os.listdir(local_folder):
        if file[0] == '.':
            continue
        
        with open(local_folder+'/'+file, 'r') as open_file:
            print(file)
            lines = open_file.readlines()
        
        with open(local_folder+'_combined'+'/'+file[:file.find('_job')]+'.txt','a+') as open_file:
            open_file.writelines(lines+['\n'])

ip_true_list = []
std_list = []

for file in os.listdir(local_folder+'_combined'):
    delta=float(file[file.find('_del_')+5:file.find('_l_')])
    l=int(file[file.find('_l_')+3:(file.find('.txt') if '_iptrue' not in file else file.find('_iptrue'))])
    
    accuracy = np.pi/(3*2**(l-3))
    
    if 'iptrue' not in file:
        ip_true = -0.2047019986566411
        continue
    else:
        ip_true = float(file[file.find('_iptrue_')+8:file.find('.txt')])
    
    ip_estimates = np.loadtxt(local_folder+'_combined/'+file)
    
    # error_rate = np.mean(np.abs((ip_estimates-ip_true)/ip_true) > accuracy)
  
    gauss_x = np.linspace(ip_estimates.min(),ip_estimates.max(),num=100)
    
    if local_folder != 'output_std_tests_ip':
        plt.hist(ip_estimates, density=True, bins=20)
        plt.axvline(ip_true, color='red')
        # plt.axvline(ip_true-accuracy, linestyle='dashed', color='red')
        # plt.axvline(ip_true+accuracy, linestyle='dashed', color='red')
        mean = np.mean(ip_estimates)
        std = np.std(ip_estimates)
        plt.plot(gauss_x, norm.pdf(gauss_x, loc = mean, scale=std))
        plt.plot([mean,mean+std], norm.pdf([mean+std,mean+std], loc = mean, scale=std), 'black')
        plt.text(mean+std*1.1, norm.pdf(mean+std, loc = mean, scale=std), rf'$\sigma={std:.4f}$')
        plt.title(rf'$l={l}$, $\delta_c={delta}$, normalized inner product: {ip_true:.4f}')
        plt.tight_layout()
        plt.savefig('figures/estimates_'+file[file.find('del_'):-4]+'.pdf')
        plt.show()

    # print()
    # print(np.std(ip_estimates))
    # print(np.std(ip_estimates/ip_true))
    
    ip_true_list.append(ip_true)
    std_list.append(np.std(ip_estimates))

#%%

if local_folder == 'output_std_tests_ip':
    assert l==5
    assert delta==0.05
    
    ind = np.argsort(ip_true_list)
    ip_true_list = np.array(ip_true_list)[ind]
    std_list = np.array(std_list)[ind]
    f = interp1d(ip_true_list, savgol_filter(std_list,60,4), kind='quadratic')

    plt.plot(ip_true_list, std_list)
    plt.plot(ip_true_list,f(ip_true_list),linewidth=1.2)
    plt.legend(['Experiment (n=3000 per point)','Smoothed and interpolated curve'])
    plt.title(rf'$l={l}$, $\delta_c={delta}$')
    plt.xlabel('normalized inner product')
    plt.ylabel('standad deviation')
    plt.savefig('figures/std_innerprod_l_5_del_0.05.pdf')


    
    with open('standard_deviation_pickle','wb+') as file:
        pickle.dump(f, file)




