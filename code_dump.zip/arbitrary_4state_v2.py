#!/usr/bin/env python3

from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, BasicAer,transpile,Aer
from qiskit.circuit import Parameter
from qiskit.algorithms import AmplitudeEstimation,EstimationProblem,FasterAmplitudeEstimation
from numpy import pi, cos, sin
import matplotlib
matplotlib.use('Qt5Agg')
import matplotlib.pyplot as plt
import numpy as np

from qiskit.quantum_info.operators import Operator
from qiskit.utils import QuantumInstance
from qiskit import IBMQ
from qiskit.extensions import UnitaryGate
from qiskit.visualization import plot_state_city

#Initialize backend - The source of Quantum. In this case we use a quantum statevector simulator
# backend = BasicAer.get_backend("statevector_simulator")
backend = BasicAer.get_backend("qasm_simulator")
quantum_instance = QuantumInstance(backend)


class BernoulliA(QuantumCircuit):
    """A circuit representing the Bernoulli A operator."""

    def __init__(self, v,c):
        super().__init__(5)  # circuit on 5 qubit

        self.h(0)
        self.state4(v)
        self.x(0)
        self.state4(c)
        self.h(0)
        
    def state2(self,c):
        c = c.reshape((2,2))
        u,s,vh = np.linalg.svd(c)
        vh = vh.transpose()
        theta = np.arccos(np.round(s[0],15))
        self.cry(2*theta,0,1)
        self.ccx(0,1,2)
        u_gate = UnitaryGate(u).control(1)
        self.append(u_gate,[0,1])
        vh_gate = UnitaryGate(vh).control(1)
        self.append(vh_gate,[0,2])
        
    def state4(self,v):
        v = v.reshape((4,4))
        u,s,vh = np.linalg.svd(v)
        vh = vh.transpose()
        self.state2(s)
        self.ccx(0,1,3)
        self.ccx(0,2,4)
        u_gate = UnitaryGate(u).control(1)
        self.append(u_gate,[0,1,2])
        vh_gate = UnitaryGate(vh).control(1)
        self.append(vh_gate,[0,3,4])
        

class state_prep(QuantumCircuit):
    def __init__(self, v):
        super().__init__(4)  # circuit on 4 qubit
        v = v/np.linalg.norm(v)
        self.state4(v)
        
    def state2(self,c):
        c = c.reshape((2,2))
        c = c.transpose()
        u,s,vh = np.linalg.svd(c)
        vh = vh.transpose()
        theta = np.arccos(np.round(s[0],15))
        self.ry(2*theta,0)
        self.cx(0,1)
        u_gate = UnitaryGate(u)
        self.append(u_gate,[0])
        vh_gate = UnitaryGate(vh)
        self.append(vh_gate,[1])
        
    def state4(self,v):
        v = v.reshape((4,4))
        v.transpose()
        u,s,vh = np.linalg.svd(v)
        vh = vh.transpose()
        self.state2(s)
        self.cx(0,2)
        self.cx(1,3)
        u_gate = UnitaryGate(u)
        self.append(u_gate,[0,1])
        vh_gate = UnitaryGate(vh)
        self.append(vh_gate,[2,3])
    
class state_prep2(QuantumCircuit):
    def __init__(self, x):
        super().__init__(2)  # circuit on 4 qubit
        x = x/np.linalg.norm(x)
        self.state2(x)
        
    def state2(self,c):
        c = c.reshape((2,2))
        c.transpose()
        u,s,vh = np.linalg.svd(c)
        vh = vh.transpose()
        theta = np.arccos(np.round(s[0],5))
        self.ry(2*theta,0)
        self.cx(0,1)
        u_gate = UnitaryGate(u)
        self.append(u_gate,[0])
        vh_gate = UnitaryGate(vh)   
        self.append(vh_gate,[1])

    
#%%
v = np.random.rand(16)
c = np.random.rand(16)
v_norm = np.linalg.norm(v)
c_norm = np.linalg.norm(c)
A = BernoulliA(v/v_norm,c/c_norm)

# A.draw(output='mpl').show()
# plt.show()
# plt.tight_layout()

fae = FasterAmplitudeEstimation(
      delta=0.3,  # target accuracy
      maxiter=2,  # determines the maximal power of the Grover operator
      quantum_instance=quantum_instance,
)

#Define estimation problem
problem = EstimationProblem(
    state_preparation=A,  # A operator
    objective_qubits=[0],  # the "good" state Psi1 is identified as measuring |1> in qubit 0
    is_good_state=None
)

#Calculate estimate for amplitude (uncomment following to use original amplitude estimation (slow))
ae_result = fae.estimate(problem)

#Compare expected result with obtained result
print('Inner product estimate: {es:.5f}'.format(es = (1-2*ae_result.estimation)))
print('Expected result       : {es:.5f}'.format(es = np.dot(v,c)/(v_norm*c_norm)))
print('Deviation:              {es:5f}'.format(es=np.abs((1-2*ae_result.estimation)-np.dot(v,c)/(v_norm*c_norm))/(np.dot(v,c)/(v_norm*c_norm))))


